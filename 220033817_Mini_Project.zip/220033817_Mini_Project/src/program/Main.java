package program;
import canvasContent.Scenes;
import javafx.application.Application;
import javafx.stage.Stage;
/**
 * 
 */

/**
 * @author Akonaho Lavhelani
 *
 */
public class Main extends Application{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		Scenes s = new Scenes(primaryStage);
	}
}
