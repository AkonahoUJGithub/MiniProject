package designPattern;
/**
 * 
 * AbstractVisitable interface for the Visitor Design Pattern
 * Used to make GameObjects drawable
 * @author Mr Lehlomela Mokoena
 *
 */
public interface IDrawable {
	
		public void accept(IDrawVisistor visitor);
}
