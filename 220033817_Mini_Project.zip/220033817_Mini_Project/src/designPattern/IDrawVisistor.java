package designPattern;

import com.jwetherell.algorithms.data_structures.Graph.Edge;

import users.User;
import users.UserNetwork;
import users.UserPresent;

/**
 * 
 * AbstractVisitor interface
 * Used to define all of the draw functions different objects
 * @author Lehlomela Mokoena
 *
 */
public interface IDrawVisistor {
	
		void draw(UserPresent ps);
		void draw(Edge<UserNetwork> e);
		void draw(User cs);
	  /*
	 * void draw(Substation ss);
	 */
}
