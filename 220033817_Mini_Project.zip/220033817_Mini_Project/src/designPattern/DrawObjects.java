package designPattern;

import com.jwetherell.algorithms.data_structures.Graph.Edge;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import users.User;
import users.UserNetwork;
import users.UserPresent;

/**
 * this is where everything comes together
 * @author lehlomela Mokoena
 *
 */
public class DrawObjects implements IDrawVisistor{
	private GraphicsContext gc;
	private static final Color power_s = Color.BLACK;
	private static final Color coal_s = Color.WHITE;
	 
	public DrawObjects(GraphicsContext gc) {
		this.gc = gc;
	}
	
	@Override
	public void draw(UserPresent ps) {
		double x = ps.getXcod();
		double y = ps.getYcod();
		gc.setFill(Color.BLACK);
		gc.fillText(ps.getName()+ "-" + (int)x + - + (int)y, (int)x - 20, (int)y - 8, 500);
		
		gc.setFill(power_s);
		gc.fillRect(ps.getXcod(), ps.getYcod(), 15, 15);
	}
	
	  @Override 
	  public void draw(User cs) { 
		  double x = cs.getXcod();
		  double y = cs.getYcod();
		  
		  gc.setFill(Color.BLACK);
		  gc.fillText(cs.getName()+ "-" + (int)x + - + (int)y, (int)x - 20, (int)y - 8, 500);
		  gc.setFill(coal_s);
		  gc.fillOval(x, y, 15, 15);
	  }
	 
	/**
	 * draws an edge between respective vertices
	 * @param allEdges 
	 */
	public void draw(Edge<UserNetwork> e) {
		gc.setStroke(Color.DARKGRAY);
		double x = e.getFromVertex().getValue().getXcod() + 5;
		double y = e.getFromVertex().getValue().getYcod() + 5;
		double x2 = e.getToVertex().getValue().getXcod() + 5;
		double y2 = e.getToVertex().getValue().getYcod() + 5;
		
		gc.strokeLine(x, y, x2, y2);
		gc.setStroke(Color.BLACK);
		if(e.getFromVertex().getValue() instanceof User) {
			gc.strokeText(Integer.toString(e.getCost()),(x+x2)/2 -5 , (y+y2)/2, 50);
		}
			
		//gc.stroke();
	}

}
