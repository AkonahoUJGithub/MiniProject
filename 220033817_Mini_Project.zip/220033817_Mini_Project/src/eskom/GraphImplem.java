package eskom;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URISyntaxException;
import java.util.Scanner;
import java.util.StringTokenizer;

import com.jwetherell.algorithms.data_structures.Graph;

import javafx.geometry.Point2D;
import traversal.Traversal;
import users.User;
import users.UserNetwork;
import users.UserPresent;
/**
 * reads the current network that already exists in eskom from file
 * 
 * allows addition removal and updating of Nodes
 * @author Lehlomela Mokoena
 *
 */
public class GraphImplem extends Graph<UserNetwork> {
	
	private final static String USERPRESENT = "USERPRESENT";
	private final static String NEWUSER = "NEWUSER";
	
	private Traversal traverse;
	private String path = "src//eskom//systUsers";
	private File file;
	private Scanner scanner;
	private StringTokenizer st;
	private StringTokenizer st_2;
	
	public GraphImplem() {
		super();
		file = new File(path);
		traverse = new Traversal();
		
		try {
			File f = new File(this.getClass().getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
			path =  f.getParent() + "src//eskom//eskomNetwork";
			
			scanner = new Scanner(file);
		}catch(URISyntaxException e){
			
		} catch (FileNotFoundException e) {
			System.err.println("File path: " + file.getAbsolutePath() + "\n");
			System.err.println("File does not exist");
		}
	}
	/**
	 * 
	 * read data from file to make graph
	 */
	public void read() {
		String line = "";
		
		while(scanner.hasNext()) {
			line = scanner.nextLine();
			st = new StringTokenizer(line,"#");
			
			String the_obj = st.nextToken();
			st_2 = new StringTokenizer(the_obj);
			/*
			 * read station details	
			 */
			String type = st_2.nextToken();
			switch(type) {
			case USERPRESENT:{
				double x = Double.parseDouble(st_2.nextToken());
				double y = Double.parseDouble(st_2.nextToken());
				UserPresent ps = new UserPresent(st_2.nextToken(), x, y);
				/*
				 * create vertex
				 */
				Vertex<UserNetwork> vertex = new Vertex<>(ps);
				getVertices().add(vertex);
				/*
				 * read all relationships
				 */
				while(st.hasMoreTokens()) {
					StringTokenizer coord = new StringTokenizer(st.nextToken());
					double x1 = Double.parseDouble(coord.nextToken());
					double y2 = Double.parseDouble(coord.nextToken());
					
					UserPresent p2 = new UserPresent("compare", x1, y2);
					
					for (Vertex<UserNetwork> v : getVertices()) {
						
						/**
						 * create relationship between power stations
						 */
						if(v.getValue().compareTo(p2) == 0) {
							Edge<UserNetwork> rel = new Edge<>(0, vertex, v);
							Edge<UserNetwork> rel2 = new Edge<>(0, v, vertex);
							
							getEdges().add(rel);
							getEdges().add(rel2);
							
							vertex.addEdge(rel);
							v.addEdge(rel2);
						}
					}
					
					
					p2 = null;
				}
			}
				break;
			case NEWUSER:{
				double xv = Double.parseDouble(st_2.nextToken());
				double yv = Double.parseDouble(st_2.nextToken());
				double quality = Double.parseDouble(st_2.nextToken());
				String name = st_2.nextToken();
					
				User cs = new User(name, xv, yv,quality);
				cs.setRandperTonne(5000);
				Vertex<UserNetwork> cs_vertex = new Vertex<>(cs);
				getVertices().add(cs_vertex);
				
				/* 
				 * connect coal supplier to power station
				 */
				for(Vertex<UserNetwork> v: getVertices()) {
					if(v.getValue() instanceof UserPresent) {//create connection
						
						Edge<UserNetwork> edge = new Edge<UserNetwork>(0, cs_vertex, v);
						Edge<UserNetwork> edge2 = new Edge<UserNetwork>(0 , v, cs_vertex);
						
						getEdges().add(edge);
						getEdges().add(edge2);
						
						v.addEdge(edge2);
						cs_vertex.addEdge(edge);
					}
				}
				
				break;
			}
		}
		}
		
	}
	/**
	 * @return Graph graph of the network
	 */
	public Graph<UserNetwork> Graph(){
		return this;
	}
	
	public Vertex<UserNetwork> deleteSupplier(User cs) {
		Vertex<UserNetwork> toret = null;
		
		for(Vertex<UserNetwork> v: getVertices()) {
			
				if(((v.getValue() instanceof User) && (v.getValue().compareTo(cs) == 0))) {
					toret = v;
					
					for(Edge<UserNetwork> e: v.getEdges()) {
						
						Vertex<UserNetwork> tov = e.getToVertex();
						Edge<UserNetwork> edge = tov.getEdge(v);
						
						tov.getEdges().remove(edge);
						getEdges().remove(edge);
					}
					
					
					getEdges().removeAll(v.getEdges());
					v.getEdges().clear();
					
				}
		}
		
		if(toret != null) getVertices().remove(toret);
		return toret;
	}
	public Boolean addSupplier(User cs) {
		boolean added = true;
		
		Vertex<UserNetwork> v = new Vertex<>(cs);
		getVertices().add(v);
		
		return added;
	}
	public String addERelatioship(double x, double y, double x2, double y2) {
	
		Vertex<UserNetwork> v1 = null;
		Vertex<UserNetwork> v2 = null;
		
		for(Vertex<UserNetwork> v : getVertices()) {
			if((v.getValue().getXcod() == x) || (v.getValue().getYcod() == y)) v1 = v;
			if((v.getValue().getXcod() == x2) || (v.getValue().getYcod() == y2)) v2 = v;

		} 
		
		if(((v1 != null) && (v2 != null))) {
			Edge<UserNetwork> e = v1.getEdge(v2);
			if((e == null)) {//undirected:

				if((v1.getValue() instanceof User) && (v2.getValue() instanceof User)) 
					return "relationship between coal suppliers not allowed";
				
				Edge<UserNetwork> e1 = new Edge<>(0,v1,v2);
				Edge<UserNetwork> e2 = new Edge<>(0,v2,v1);
				
				v1.addEdge(e1);
				v2.addEdge(e2);
				
				getEdges().add(e1);
				getEdges().add(e2);
				
				return "relationship has been added";
			}
			return "relationship already exists";
			
		}else
			return "one or both locations do not exist in the graph";
	}
	public String removeRel(double x, double y, double x1, double y1) {
		
		Vertex<UserNetwork> v = traverse.BFS_findVertex(getVertices().get(0), new Point2D(x, y));
		Vertex<UserNetwork> v1 = traverse.BFS_findVertex(getVertices().get(0), new Point2D(x1, y1));
		
		if(((v != null) && (v1 != null))) {
			
			Edge<UserNetwork> e = v.getEdge(v1);
			Edge<UserNetwork> e2 = v1.getEdge(v); 
			
			if(((e!=null) ) || (e2 != null)) {
				
				v.getEdges().remove(e);
				v1.getEdges().remove(e2);
				
				getEdges().remove(e);
				getEdges().remove(e2);
				return "relatioship removed";
				
			}else return "no relationship between edges";
			
		}
		
		return "one or both vertices do not exist";
	}
	
	public Vertex<UserNetwork> getVertex(double x, double y) {
		
		for(Vertex<UserNetwork> v : getVertices()) 
			if((v.getValue().getXcod() == x) || (v.getValue().getYcod() == y)) return v;

		return null;
		
	}
	
	/**
	 * Finds all overpaid stations and removes them from the network
	 * @return String message about the result of the audit
	 */
	public String Bfs_findOverpaid() {
		/*
		 * List<CostVertexPair<ElectricityNetwork>> cvp; traverse.reset(); return
		 * traverse.bfs_overpaid(this.getVertices().get(0),cvp);
		 */
		return null;
	}
}
