package users;

import designPattern.IDrawVisistor;

public class User extends UserNetwork{

	private double coal_quality;
	private double RandperTonne = 0;
	
	 
	public User(String name, double x, double y, double cq) {
		super(name, x, y);
		coal_quality = cq;
		
	}

	@Override
	public void accept(IDrawVisistor visitor) {
		visitor.draw(this);
	}

	/**
	 * @return the coal_quality
	 */
	public double getCoal_quality() {
		return coal_quality;
	}

	/**
	 * @param coal_quality the coal_quality to set
	 */
	public void setCoal_quality(double coal_quality) {
		this.coal_quality = coal_quality;
	}

	/**
	 * @return the randperTonne
	 */
	public double getRandperTonne() {
		return RandperTonne;
	}

	/**
	 * @param randperTonne the randperTonne to set
	 */
	public void setRandperTonne(double randperTonne) {
		RandperTonne = randperTonne;
	}

	
	@Override
	public int compareTo(UserNetwork n) {
		if((n.xcod != this.xcod)) return -1;
		if((n.ycod != this.ycod)) return -1;
			

		return 0;
	}
	

}
