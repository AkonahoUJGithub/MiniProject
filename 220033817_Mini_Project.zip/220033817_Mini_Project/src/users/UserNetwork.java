package users;

import designPattern.IDrawable;

/**
 * interface that defines all object contribute to the generation of electricity
 * @author Lehlomela MOkoena
 *
 */
public abstract class UserNetwork implements Comparable<UserNetwork> ,IDrawable{

	protected String name;
	protected double xcod;
	protected double ycod;
	

	public UserNetwork(String name, double x, double y) {
		this.name = name;
		xcod = x;
		ycod = y;
		
	}
	

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public double getXcod() {
		return xcod;
	}
 
	
	public void setXcod(double xcod) {
		this.xcod = xcod;
	}

	/**
	 * compare two electric network objects
	 * 
	 * OBJECTS ARE ASSUMED TO HAVE DIFFERENT LOCATIONS FOR SIMPLICITY
	 * 
	 * used for removals
	 * 
	 * @param n oject to compare 
	 * @return boolean value indicating match
	 */
	

	public double getYcod() {
		return ycod;
	}



	public void setYcod(double ycod) {
		this.ycod = ycod;
	}

}
