package users;

import designPattern.IDrawVisistor;

public class UserPresent extends UserNetwork{

	public UserPresent(String name, double x, double y) {
		super(name, x, y);
	}

	@Override
	public void accept(IDrawVisistor visitor) {
		visitor.draw(this);
	}

	@Override
	public int compareTo(UserNetwork n) {
		if((n.xcod != this.xcod)) return -1;
		if((n.ycod != this.ycod)) return -1;
			

		return 0;
	}
}
