package canvasContent;


import java.util.StringTokenizer;

import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import eskom.GraphImplem;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import users.User;
import users.UserNetwork;
/**
 * this is where everything comes together
 * 
 * Adding, updating and removal of Nodes
 * 
 * @author Lehlomela Mokoena
 *
 */
public class Scenes{
	private Scene scene;
	private DrawCanvSpace canv;
	private HBox root;
	private VBox options;
	private Alert alert;
	private GraphImplem graph;
	final static String  format = "invalid format \nexample: 233-12";
	final static String regex1 = "(\\w+)[-](\\d*)[-](\\d*)";
	final static String regex2 =  "(\\d*)\\d{1}[-](\\d*)\\d{1}";
	Vertex<UserNetwork> v;
	
	public Scenes(Stage prim) {
		VBox space = new VBox();
		canv = new DrawCanvSpace();
		graph = new GraphImplem();
		graph.read();
		canv.draw(graph);
		
		space.setSpacing(5);
		root = new HBox();
		root.getChildren().add(space);
		root.setSpacing(10);
		options = new VBox();
		
	/*
	 * setup user options
	 */
		Button add_cs = new Button("ADD USER");
		add_cs.setMinWidth(230);
	//delete coal suplier
		Label fter = new Label("-------------------------------------------\n");
		Label delete = new Label("\nDetails as u see on canvas");
		TextField deletedet = new TextField();
		Button deleteNode = new Button("DELETE USER");
		deleteNode.setMinWidth(230);
	//update node
		Label up = new Label("-------------------------------------------\n");
		Label update = new Label("\nDetails as u see on canvas");
		TextField updatedetails = new TextField();
		Button updateNode = new Button("UPDATE USER");
		updateNode.setMinWidth(230);
	//add edge
		Label addyy = new Label("-------------------------------------------\n\n");
		Label fromadd = new Label("From Vertex (location)");
		TextField fromNodeadd = new TextField();
		Label toadd = new Label("to vertex (location)");
		TextField toNodeadd = new TextField();
		Button addedge = new Button("Add Edge");
	//edit/delete edge
		/*
		 * Label editE = new Label("-------------------------------------------\n\n");
		 * Label from = new Label("From Vertex (location)"); TextField fromNode = new
		 * TextField(); Label to = new Label("to vertex (location)"); TextField toNode =
		 * new TextField(); Button edit = new Button("Edit Edge");
		 */
		Button deledge = new Button("delete Edge");
		deledge.setMinWidth(230);
		addedge.setMinWidth(230);
	//audit power stations
		Label down = new Label("-------------------------------------------\n");
		Label auditsta = new Label("\nAudit power Station");
		Button audit = new Button("Audit");
		audit.setMinWidth(230);
		
		options.getChildren().addAll(new Label(),add_cs,fter,delete,deletedet,deleteNode,up,update,updatedetails,
									updateNode,addyy,fromadd,fromNodeadd,toadd,toNodeadd,addedge,/*editE,
									from,fromNode,to,toNode,edit,*/deledge,down,auditsta,audit);
	/*
	 * supplier input details
	 */
		VBox fillsupplier = new VBox();
		
		Label name = new Label("Name");
		TextField namedet = new TextField();
		//price paid on coal
		Label Rtonne = new Label("\nRand/tonne (nearest rand)");
		TextField rtonnedet = new TextField();
		//coal quality
		Label quality = new Label("\nQuality of Coal(1-100)");
		TextField qualitydet = new TextField();
		//location
		Label coord = new Label("\nLocation(click canvas)");
		VBox loc = new VBox();
		TextField xcord = new TextField();
		xcord.setEditable(false);
		TextField ycord = new TextField();
		ycord.setEditable(false);
		loc.getChildren().addAll(xcord,ycord);
		
		//get stations to supply
//		Label stations = new Label("\nStations(separated by~)\nwith location");
//		TextArea area = new TextArea();
		//option to cancel
		Button submit = new Button("Submit");
		submit.setMinWidth(230);
		Button cancel = new Button("back");
		cancel.setMinWidth(230);
		Button updateCS = new Button("Update");
		updateCS.setMinWidth(230);
		
		fillsupplier.getChildren().addAll(name,namedet,Rtonne,rtonnedet,quality,qualitydet,coord,
											loc,submit,cancel);
		
		
		root.getChildren().addAll(options, canv);
	
		scene = new Scene(root);
		
		prim.setScene(scene);
		prim.setWidth(canv.getWidth() + 250);
		prim.show();
		
		
		/*
		 * ******************************event listeners****************
		 */
		
	/*
	 * add coal supplier
	 */
		add_cs.setOnAction((event)->{
			
			root.getChildren().remove(1);
			root.getChildren().add(1,fillsupplier);
		});
		
		submit.setOnAction((event)->{
			boolean correct = true;
			//some error handling
			if(!rtonnedet.getText().matches("[1-9]\\d*")) correct = false;
			if(!qualitydet.getText().matches("[1-9]\\d*")) correct = false;
			if(xcord.getText().isEmpty()) correct = false;
			if(ycord.getText().isEmpty()) correct = false;
			if(namedet.getText().trim().isEmpty()) correct = false;
			
			if(correct) {
				String csname = namedet.getText().trim();
				double pricepertonne = Double.parseDouble(rtonnedet.getText().trim());
				double qua = Double.parseDouble(qualitydet.getText().trim());
				double x = Double.parseDouble(xcord.getText().trim());
				double y = Double.parseDouble(ycord.getText().trim());
				
				User cs = new User(csname.toUpperCase(), x, y, qua);
				cs.setRandperTonne(pricepertonne);
				
				if(graph.addSupplier(cs)) showAlert(AlertType.INFORMATION, "Supplier added");
				
				canv.draw(graph);
				
			}else
				showAlert(AlertType.ERROR, "incorrect input - verify input");
			
			
		});
	/*
	 * delete coal supplier
	 */
		deleteNode.setOnAction((event)-> {
			if(deletedet.getText().matches(regex1)) {
				
				StringTokenizer st = new StringTokenizer(deletedet.getText().trim(),"-");
				User cs = new User(st.nextToken(), Double.parseDouble(st.nextToken()), 
												Double.parseDouble(st.nextToken()), 0);	
					
				
				Object obj = graph.deleteSupplier(cs);
				
				if(obj != null) {
					showAlert(AlertType.INFORMATION, "coal supplier successfully deleted");
				}else
					showAlert(AlertType.INFORMATION, "coal supplier does not exist");
			
				
				canv.draw(graph);
			}else
				showAlert(AlertType.INFORMATION, "format incorrect");
		});
	/*
	 * adding location of coal supplier
	 */
		canv.setOnMouseClicked((event)->{
			ycord.setText(Double.toString(event.getY()));
			xcord.setText(Double.toString(event.getX()));
		});
		/*
		 * cancel adding supplier details
		 */
		cancel.setOnAction((event)->{
			fillsupplier.getChildren().remove(8);
			fillsupplier.getChildren().add(8, submit);
			root.getChildren().remove(1);
			root.getChildren().add(1, options);
		});
	/*
	 *delete node with respective edges 
	 */
		deledge.setOnAction(event->{
			boolean cont = true;
			if(!toNodeadd.getText().matches(regex2)) cont = false;
			if(!fromNodeadd.getText().matches(regex2)) cont = false;
			
			if(cont) {
				StringTokenizer stfrom = new StringTokenizer(fromNodeadd.getText().trim(),"-");
				StringTokenizer stto = new StringTokenizer(toNodeadd.getText().trim(),"-");
				
				double x = Double.parseDouble(stfrom.nextToken());
				double y = Double.parseDouble(stfrom.nextToken());
				
				double x1 = Double.parseDouble(stto.nextToken());
				double y1 = Double.parseDouble(stto.nextToken());
				
				showAlert(AlertType.INFORMATION, graph.removeRel(x,y,x1,y1));
				canv.draw(graph);
				
				
			}else 
				showAlert(AlertType.ERROR, format);
			
		});
	/*
	 * add edge
	 */
		addedge.setOnAction(event->{
			boolean cont = true;
			if(!toNodeadd.getText().matches(regex2)) cont = false;
			if(!fromNodeadd.getText().matches(regex2)) cont = false;
			
			if(cont) {
				StringTokenizer stfrom = new StringTokenizer(fromNodeadd.getText().trim(),"-");
				StringTokenizer stto = new StringTokenizer(toNodeadd.getText().trim(),"-");
				
				double x = Double.parseDouble(stfrom.nextToken());
				double y = Double.parseDouble(stfrom.nextToken());
				
				double x2 = Double.parseDouble(stto.nextToken());
				double y2 = Double.parseDouble(stto.nextToken());
			
				showAlert(AlertType.INFORMATION, graph.addERelatioship(x,y,x2,y2));
				canv.draw(graph); 
				
			}else 
				showAlert(AlertType.ERROR, format);
			
		});
		
		updateNode.setOnAction(e->{
			
			if((updatedetails.getText().trim().matches(regex2))) {
				
				
				
				StringTokenizer st = new StringTokenizer(updatedetails.getText().trim(),"-");
				double x = Double.parseDouble(st.nextToken());
				double y = Double.parseDouble(st.nextToken());
				
			    v = graph.getVertex(x,y);
			    if(v != null) {
			    	if(v.getValue() instanceof User) {
			    		root.getChildren().remove(1);
						fillsupplier.getChildren().remove(8);
						fillsupplier.getChildren().add(8, updateCS);
						root.getChildren().add(1,fillsupplier);
						
						User c = (User)v.getValue();
						namedet.setText(v.getValue().getName());
						rtonnedet.setText(Integer.toString((int)c.getRandperTonne()));
						qualitydet.setText(Integer.toString((int)c.getCoal_quality()));
						
						xcord.setText(Double.toString(c.getXcod()));
						ycord.setText(Double.toString(c.getYcod()));
						
						

			    	}else showAlert(AlertType.ERROR, "cannot edit power station");
			    	
			    	
			    }else showAlert(AlertType.ERROR, "Vertex does not exist");
			    
			 /*
			  * update coal supplier
			  * 
			  */
			    updateCS.setOnAction(event->{
			    	boolean correct = true;
					//some error handling
					if(!rtonnedet.getText().matches("[1-9]\\d*")) correct = false;
					if(!qualitydet.getText().matches("[1-9]\\d*")) correct = false;
					if(xcord.getText().isEmpty()) correct = false;
					if(ycord.getText().isEmpty()) correct = false;
					if(namedet.getText().trim().isEmpty()) correct = false;
					
					if(correct) {
						String csname = namedet.getText().trim();
						double pricepertonne = Double.parseDouble(rtonnedet.getText().trim());
						double qua = Double.parseDouble(qualitydet.getText().trim());
						double x2 = Double.parseDouble(xcord.getText().trim());
						double y2 = Double.parseDouble(ycord.getText().trim());
						
						User cs = new User(csname, x2, y2, qua);
						cs.setRandperTonne(pricepertonne);
						
						((User)v.getValue()).setName(csname);
						((User)v.getValue()).setRandperTonne(pricepertonne);
						((User)v.getValue()).setCoal_quality(qua);
						((User)v.getValue()).setXcod(x2);
						((User)v.getValue()).setYcod(y2);;
						canv.draw(graph);
					}else
						showAlert(AlertType.ERROR, "incorrect input - verify input");
			    });
			    
			}else
				showAlert(AlertType.ERROR, format);
		});
	/*
	 * audit the power stations
	 */
		audit.setOnAction(event->{
			
			showAlert(AlertType.INFORMATION, graph.Bfs_findOverpaid());
			
		});
	}

	private void showAlert(AlertType p, String mess) {
		alert = new Alert(p);
		alert.setHeaderText(mess);
		alert.setContentText("");
		alert.show();
		
	}
	
}
