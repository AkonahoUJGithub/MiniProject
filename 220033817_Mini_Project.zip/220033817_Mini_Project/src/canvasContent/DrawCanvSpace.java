package canvasContent;

import com.jwetherell.algorithms.data_structures.Graph;
import com.jwetherell.algorithms.data_structures.Graph.Edge;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import designPattern.DrawObjects;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import users.UserNetwork;

public class DrawCanvSpace extends Canvas{
	
	private static final int HEIGHT = 710;
	private static final int WIDTH = 830;
	
	private DrawObjects drawer;
	
	private GraphicsContext gc;
	
	public DrawCanvSpace() { 
		super();
		setHeight(HEIGHT);
		setWidth(WIDTH);
		
		gc = getGraphicsContext2D();
		drawer = new DrawObjects(gc);
	}
	
	/**
	 * draws provided graph on canvas
	 * @param g Graph to draw
	 */
	public void draw(Graph<UserNetwork> g) {
		
		gc = this.getGraphicsContext2D();
		gc.setFill(Color.GREY);
		gc.clearRect(0, 0, getWidth(), getHeight());
		gc.fillRect(0, 0, getWidth(), getHeight());
		
		/*
		 * draw the edges
		 */
		for(Edge<UserNetwork> e : g.getEdges()) 
			drawer.draw(e);
 			
		/*
		 * display existing network
		 */
		for (Vertex<UserNetwork> v : g.getVertices()) 
			v.getValue().accept(drawer);
		
	}
	
}
