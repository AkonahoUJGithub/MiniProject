package traversal;

import java.util.ArrayList;
import java.util.List;

import com.jwetherell.algorithms.data_structures.Graph;
import com.jwetherell.algorithms.data_structures.Graph.CostVertexPair;
import com.jwetherell.algorithms.data_structures.Graph.Edge;
import com.jwetherell.algorithms.data_structures.Graph.Vertex;

import javafx.geometry.Point2D;
import users.User;
import users.UserNetwork;
import users.UserPresent;

public class Traversal {
	
	//private Runtime runtime = Runtime.getRuntime();
	private Queue<Vertex<UserNetwork>> q = new Queue<>(); 
	private ArrayList<Vertex<UserNetwork>> visited = new ArrayList<>();
	
	/**
	 * default constructor
	 */
	public Traversal() {
		reset();
	}
	/**
	 * perform Breadth First Search to connect a vertex(coal supplier) to coal power Stations
	 * @param graph Graph to traverse
	 * @param start vertex to start traversal
	 * @param connect2 vertex(coal supplier) to connect to new graph
	 * @return Graph with the connected vertices
	 */
	public Graph<UserNetwork> BFS_connectoPowerStations(Graph<UserNetwork> graph, Vertex<UserNetwork> start,
															   Vertex<UserNetwork> connect2) {
		
		//Graph<ElectricityNetwork> newGraph = new Graph<>(graph);
		connect2powerStation(graph, start, connect2);
		
		reset();
		return graph;
	}

	/**
	 * helper function for connecting to power stations
	 * @param newG graph with connected edges
	 * @param oldG graph to connect new vertex
	 * @param start vertex to start traversal
	 * @param conect vertex(coal supplier) to connect to new graph
	 */
	private void connect2powerStation(Graph<UserNetwork> newG,
									  Vertex<UserNetwork> start, Vertex<UserNetwork> conect){
		
		User cs = (User)conect.getValue();
		
		if(!visited.contains(start)) {
			add(start);
			
			if(start.getValue() instanceof UserPresent) 
				createConnection(newG, start, conect, (int)cs.getCoal_quality());
		}
		
		for(Edge<UserNetwork> e: start.getEdges()) {
			
			Vertex<UserNetwork> A = e.getToVertex();
			
			if(!visited.contains(A)) {
				add(A);
				if(A.getValue() instanceof UserPresent)
					createConnection(newG, A, conect, (int)cs.getCoal_quality());
				else continue;
			}
				
		}
		q.dequeue();
		if(!q.isEmpty()) connect2powerStation(newG, q.first(), conect);
		cs = null;
	}
	
	/**
	 * function to create connection between two vertices
	 * @param graph Graph to add connection
	 * @param start start vertex
	 * @param conect end Vertex
	 */
	private void createConnection(Graph<UserNetwork> graph, Vertex<UserNetwork> start, Vertex<UserNetwork> end, int w) {
		Edge<UserNetwork> edge = new Edge<>(w , end, start);
		Edge<UserNetwork> edge2 = new Edge<>(w , start, end);
		
		start.getEdges().add(edge2);
		end.getEdges().add(edge);
		
		graph.getEdges().add(edge2);
		graph.getEdges().add(edge);
		 
	}
	
	/**
	 * add vertex to queue and list of visited node
	 * @param A vertex to add
	 */
	private void add(Vertex<UserNetwork> A) {
		q.enqueue(A);
		visited.add(A);
	}
	/**
	 * reset properties
	 */
	public void reset() {
		q = new Queue<>();
		visited.clear();
	}
	
	/**
	 * Node has to be connected to network
	 * @param start
	 * @param one
	 * @return
	 */
	public Vertex<UserNetwork> BFS_findVertex(Vertex<UserNetwork> start,Point2D one) {
	
		Vertex<UserNetwork> v = connecthelp(start,one);
		
		reset();
		return v;
	}
	
	
	private Vertex<UserNetwork> connecthelp(Vertex<UserNetwork> start, Point2D point) {
		
		if(!visited.contains(start)) {
			add(start);
			
			if((start.getValue().getXcod() == point.getX()) || (start.getValue().getYcod() == point.getY())) 
				return start;
		}
		
		for(Edge<UserNetwork> e: start.getEdges()) {
			
			Vertex<UserNetwork> A = e.getToVertex();
			add(A);
			
			if((A.getValue().getXcod() == point.getX()) || (A.getValue().getYcod() == point.getY())) 
				return A;
				
		}
		q.dequeue();
		if(!q.isEmpty()) return connecthelp(q.first(), point);
		return null;
	}
	
	public String bfs_getCoalsuppliers(Vertex<UserNetwork> start, List<CostVertexPair<UserNetwork>> css) {
		CostVertexPair<UserNetwork> cvp = null;
		
		if(!visited.contains(start)) {
			add(start);
			
			if(start.getValue() instanceof User) {
				cvp = new CostVertexPair<>(start.getWeight(), start);
				css.add(cvp);
			}
				
				
		}
		
		for(Edge<UserNetwork> e: start.getEdges()) {
			
			Vertex<UserNetwork> A = e.getToVertex();
			add(A);
			
			
				
		}
		q.dequeue();
		if(!q.isEmpty()) return bfs_getCoalsuppliers(q.first(),css);

		return null;
	}
	
	
	
	
}
