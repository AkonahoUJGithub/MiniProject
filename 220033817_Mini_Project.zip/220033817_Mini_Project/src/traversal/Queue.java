package traversal;

import java.util.ArrayList;

/**
 * 
 * @author lehlomela Mokoena
 *
 * @param <T>
 */
public class Queue<T> {

	private ArrayList<T> que;
	
	/**
	 * default constructor
	 */
	public Queue() {
		que = new ArrayList<> ();
	}
	
	/**
	 * returns first element without removing it
	 * @return T first element in the queue
	 */
	public T first(){
		return que.get(0);
	}
	
	/**
	 * removes an return the first element in the queue
	 * @return T first element in queue
	 */
	public T dequeue() {
		T elem = que.remove(0);
		return elem;
	}
	
	/**
	 * add elemet e to back of queue
	 * @param e element to add
	 */
	public void enqueue(T e) {
		que.add(e);
	}
	
	/**
	 * get size of queue
	 * @return size size of queue
	 */
	public int size() {
		return que.size();
	}
	
	/**
	 * determines whether queue is empty
	 * @return boolean
	 */
	public boolean isEmpty() {
		return size() == 0;
	}
}
